package com.BHC.TRAVEL.HYEN_SHAN;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HyenShanApplicationTests {

	@Test
	void contextLoads() {
	}

}
