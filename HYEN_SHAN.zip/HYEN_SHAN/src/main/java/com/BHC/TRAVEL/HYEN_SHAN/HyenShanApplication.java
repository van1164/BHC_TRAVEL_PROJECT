package com.BHC.TRAVEL.HYEN_SHAN;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HyenShanApplication {

	public static void main(String[] args) {
		SpringApplication.run(HyenShanApplication.class, args);
	}

}
